# A README file for the Oracle NoSQL Database Cloud Simulator.

## Requirements

The Oracle NoSQL Cloud Simulator requires at least Java 8, but we recommend
that you use at least Java 10.

The Oracle NoSQL Cloud Simulator runs on your local computer and has
been tested on the following operating systems:

* Windows 7 and above
* Oracle Linux
* Mac OS

## Overview

The Cloud Simulator is a standalone server that supports the protocol used
by Oracle NoSQL language SDK implementations such as the Oracle NoSQL
Database Java SDK.  This utility gives developers the ability to test
applications without connecting to the Oracle NoSQL Database
Cloud Service itself.

This document describes how to start an Oracle NoSQL Database Cloud Simulator
instance.

## Before you Start

* These instructions assume that the current directory is the root
directory of the archive (the directory that contains this file).
* To properly develop an application, an appropriate client SDK is
needed. The SDKs are separate downloads.
* The Oracle NoSQL Cloud Simulator cannot be used to store any production
data.
* You must have at least 1GB of free disk on the volume containing the root
directory.

## Configure and Start the Cloud Simulator

Shell scripts are provided as a convenience to run the Oracle
NoSQL Cloud Simulator. These scripts specify an included
logging configuration file. By default, there is no logging.

1. Edit the file, logging.properties, to enable the level of logging
desired.

2. Start the Oracle NoSQL Cloud Simulator. The only required option is
"-root" which defines the store's directory. If this directory does
not already exist, it will be created. If there is an existing
store present in that directory, it will be used.

        $ ./runCloudSim -root <path-to-a-rootdir>

This call creates an instance of the Oracle NoSQL Cloud Simulator and
starts a cloud server in the same process using the default ports
for the store and cloud server. The cloud server listens for cloud driver
requests on an HTTP port.

### Additional Parameters

There are additional options that can be used to control the Cloud
Simulator instance.

Options and default values:

      -host (default: localhost): allows control over the database
       host used

      -storePort (default: 5000): allows control over the database
       port used

      -httpPort (default: 8080): allows control over the HTTP port
       used

      - storageSize (default: 15): sets the size of the underlying storage
       in GB. This value is ignored if the root already exists and has a
       store.

      -throttle (default: false): enables throttling based on declared
       throughput

      -verbose (default: false): adds verbosity to output. If set to
       true throttling exceptions will be thrown if throughput is
       exceeded.

To see the usage message:

       $ ./runCloudSim -?

Oracle NoSQL Cloud Simulator can be put in the background using:

       $  ./runCloudSim -root <path-to-a-rootdir> &

The Oracle NoSQL Cloud Simulator instance can be stopped using ^C or
otherwise killing the process.

To remove all data, stop the Oracle NoSQL Cloud Simulator instance and remove
all files under the specified root directory.

### Download an SDK

Download and use an SDK for the Oracle NoSQL Database Cloud Service. The SDKs
include information on how to run example programs against the Oracle NoSQL
Cloud Simulator. The supported SDK downloads can be found on the
[Oracle NoSQL Database Download Page](https://www.oracle.com/database/technologies/nosql-database-server-downloads.html).

## Differences Relative to the Oracle NoSQL Cloud Service

The differences can be found on the [Oracle NoSQL Cloud Simulator Comparison](https://docs.oracle.com/en/cloud/paas/nosql-cloud/csnsd/cloud-sim-nosql-database-cloud-service.html) page. They are reproduced here.


* There are no hard limits enforced on number of tables, size of tables, number
of indexes, or maximum throughput specified for a table.
* Throttling of applications based on table throughput is optional and off by
default. It can be enabled using the *-throttle true* argument.
* Data Definition Language (DDL) statements, such as creating or dropping
tables, are not throttled.
* Operational history is not maintained.
* The Oracle NoSQL Cloud Simulator does not support any secure configuration
or access control.
* The Oracle NoSQL Cloud Simulator does not support table names prefixed
with a compartment name as there are no compartments in the simulator.
* There is no browser based user interface (UI) available for the Oracle NoSQL
Cloud Simulator.

## Troubleshooting

1. Failure to start the Oracle NoSQL Cloud Simulator server.

  a) failed to start KVLite. This might occur if there is a process
  using the default port 5000. In this case use a different port using
  -storePort <port>

  b) failed to start the cloud server. This might occur if there is a process
  using the default port of 8080. In this case use the -httpPort
  <port> flag to use a non-default port. This also means specifying
  -httpPort <port> when calling the example classes which have a
  hard-coded default of 8080.

2. Example application fails to connect to the server. If using the
simulator, this probably means that the Oracle NoSQL Cloud Simulator
server isn't running, or is running using a different endpoint than the
one used by the examples. These need to match.

## Help and Support

Support for Oracle NoSQL Cloud Simulator is provided over the
[Oracle NoSQL Database Forum](https://community.oracle.com/community/database/nosql_database).

You can also email to: *oraclenosql-info_ww@oracle.com*
with *Oracle NoSQL Cloud Simulator* in the subject line.

## LICENSES

See the [LICENSE](LICENSE.txt) file.

The [THIRD\_PARTY\_LICENSES](THIRD_PARTY_LICENSES.txt) file contains
third party notices and licenses.

The following libraries in this download are Oracle libraries and are under
the OTN developer license, as per the download:

   cloudsim.jar
   je.jar
   kvstore.jar
   kvstore-ee.jar
   httpproxy.jar
   httpserver.jar
